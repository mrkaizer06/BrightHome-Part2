document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");

  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
    });

    links.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        links.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.setAttribute("aria-label", "Open navigation");
      });
    });
  }

  const year = document.querySelector("[data-year]");
  if (year) year.textContent = new Date().getFullYear();

  // Service cards can pass a selected service to the enquiry form.
  const serviceSelect = document.querySelector("#service");
  if (serviceSelect) {
    const service = new URLSearchParams(window.location.search).get("service");
    if (service) {
      const option = [...serviceSelect.options].find(
        item => item.value.toLowerCase() === service.toLowerCase()
      );
      if (option) serviceSelect.value = option.value;
    }
  }

  document.querySelectorAll("form[data-demo-form]").forEach(form => {
    const status = form.querySelector(".form-status");
    form.addEventListener("submit", event => {
      event.preventDefault();

      if (!form.checkValidity()) {
        status.textContent = "Please complete the required fields before submitting.";
        status.className = "form-status error";
        form.reportValidity();
        return;
      }

      status.textContent =
        "Thank you. Your enquiry has been captured for this demonstration website. " +
        "A BrightHome team member would normally respond during business hours.";
      status.className = "form-status success";
      form.reset();
    });
  });
});
