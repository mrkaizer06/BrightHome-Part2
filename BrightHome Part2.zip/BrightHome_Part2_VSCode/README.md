# BrightHome Part 2 — CSS Styling and Responsive Design

## Project overview
**Organisation:** BrightHome Electrical & Maintenance (fictional academic organisation)  
**Part:** Part 2 — Designing the Visuals: CSS Styling and Responsive Design  
**Technology:** HTML5, CSS3 and vanilla JavaScript  
**Editor:** Visual Studio Code

Part 2 continues directly from the BrightHome Part 1 website. The existing five-page structure and content have been retained while the visual system, responsive behaviour, interactions, responsive imagery and documentation have been strengthened.

## Pages
- `index.html` — Home
- `about.html` — About
- `services.html` — Services
- `enquiry.html` — Enquiry
- `contact.html` — Contact

## What was added for Part 2

### CSS styling
- Shared external `css/style.css` linked across all pages.
- CSS reset and reusable root variables.
- Consistent colour palette, typography, spacing, borders and shadows.
- Responsive typography using `clamp()`.
- CSS Grid and Flexbox layouts.
- Reusable cards, panels, buttons, banners and form controls.
- `:hover`, `:focus-visible` and `:active` interaction states.

### Responsive design
- Desktop, tablet and mobile breakpoints.
- Multi-column desktop layouts that collapse to single-column mobile layouts.
- Responsive navigation menu.
- Relative units including `%`, `rem`, `vw` and `clamp()`.
- Responsive form and footer layouts.

### Responsive images
The Home page hero uses:
- `<picture>`
- `srcset`
- `sizes`
- `assets/hero-small.svg`
- the existing `assets/hero.svg`

This allows the browser to select an appropriate image source based on the viewport.

### JavaScript
The existing form demonstration and validation were retained. The Part 2 update also:
- improves the mobile navigation's accessible label;
- closes mobile navigation after a link is selected;
- supports service pre-selection when a visitor follows a service enquiry link.

## Folder structure
```text
BrightHome_Part2_VSCode/
├── assets/
│   ├── hero.svg
│   ├── hero-small.svg
│   └── logo.svg
├── css/
│   └── style.css
├── docs/
│   ├── changelog.md
│   ├── content-research.md
│   ├── part2-requirements.md
│   ├── proposals.md
│   ├── responsive-testing.md
│   ├── sitemap.md
│   ├── submission-checklist.md
│   └── screenshots/
├── js/
│   └── script.js
├── about.html
├── contact.html
├── enquiry.html
├── index.html
├── services.html
├── .gitignore
└── README.md
```

## Running in Visual Studio Code
1. Extract the ZIP.
2. Open Visual Studio Code.
3. Select **File → Open Folder**.
4. Open `BrightHome_Part2_VSCode`.
5. Open `index.html`.
6. Use the **Live Server** extension if installed, or open `index.html` directly in a browser.
7. Test the navigation, buttons, service links and forms.

## Responsive testing
The project includes screenshot evidence for:
- Desktop: **1440 × 900**
- Tablet: **1024 × 900**
- Mobile: **390 × 844**

See `docs/responsive-testing.md`.

## GitHub submission preparation
The assignment asks for regular descriptive commits and a push to the remote repository. The local project is prepared for GitHub, but pushing requires the student's own GitHub account and authentication.

Suggested commit sequence:
1. `Update shared CSS styling for Part 2`
2. `Add responsive breakpoints and mobile navigation`
3. `Add responsive image sources`
4. `Improve JavaScript navigation interaction`
5. `Add Part 2 changelog and requirements traceability`
6. `Add responsive testing evidence and update README`

Typical commands after creating/connecting the student's GitHub repository:
```bash
git init
git add .
git commit -m "Complete BrightHome Part 2 CSS and responsive design"
git branch -M main
git remote add origin <YOUR-GITHUB-REPOSITORY-URL>
git push -u origin main
```

## References
The Part 1 research references are retained in `docs/content-research.md`.

Additional references relevant to the Part 2 implementation:
1. MDN Web Docs — CSS media queries: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
2. MDN Web Docs — Responsive images: https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
3. MDN Web Docs — CSS Grid Layout: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
4. MDN Web Docs — Flexbox: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
5. MDN Web Docs — CSS pseudo-classes: https://developer.mozilla.org/en-US/docs/Web/CSS/Pseudo-classes

## Academic note
BrightHome is a fictional organisation created for the assignment. The enquiry and contact forms demonstrate client-side behaviour only; they do not transmit data to a live server.

For the specific Part 2 requirements and how each was implemented, see `docs/part2-requirements.md`.

### Colour scheme
The website uses a consistent colour system throughout the pages: deep navy for structure and headings, blue for interactive/brand accents, warm orange for calls-to-action and highlights, plus light blue and cream backgrounds. These colours are defined as reusable CSS variables in `css/style.css`.
