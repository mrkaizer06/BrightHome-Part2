# Part 1 — Website Project Proposals

## Proposal 1 — BrightHome Electrical & Maintenance (Selected)

### 1. Organisation overview
BrightHome Electrical & Maintenance is a hypothetical small local service business created for this project. It provides practical residential electrical and maintenance support to homeowners and tenants in Johannesburg and surrounding areas. Its mission is to make home service support easier to understand, request and schedule. The primary target audience is busy homeowners who need clear information before deciding whether to contact a service provider.

### 2. Website goals and objectives
The website's main goal is to establish a professional online presence that turns visitors into enquiries. The objectives are to explain the organisation and its service areas clearly, make contact information easy to find, encourage quote requests, and provide a consistent experience on desktop and mobile devices. Suggested key performance indicators (KPIs) are completed enquiry forms, click-throughs to the enquiry page, contact-link clicks, and average engagement with service pages.

### 3. Current website analysis
A current website analysis is not applicable because BrightHome is a fictional organisation created for the assignment. The project therefore treats the website as a new digital presence rather than a redesign.

### 4. Proposed features and functionality
The proposed website contains five linked HTML pages: Home, About, Services, Enquiry and Contact. The Home page introduces the organisation and provides strong calls to action. The About page explains the mission, vision, audience and objectives. The Services page gives concise descriptions and links visitors directly to an enquiry. The Enquiry page uses HTML form controls, required fields and client-side validation. The Contact page provides contact information and a second simple message form. A responsive navigation menu and reusable CSS create a consistent layout.

### 5. Design and user experience
The design uses a professional navy, blue and orange palette, readable typography, rounded cards and clear spacing. The hierarchy is deliberately simple: visitors should understand what BrightHome does, trust the information, and reach an enquiry form within a few clicks. The layout is responsive so the navigation and content remain usable on smaller screens.

### 6. Technical requirements
The website is built in Visual Studio Code using semantic HTML5, CSS3 and vanilla JavaScript. No framework or database is required for Part 1. The folder structure separates pages, CSS, JavaScript, assets and documentation. The forms use labels, appropriate input types and browser validation features, with JavaScript providing a user-friendly demonstration response.

### 7. Timeline and milestones
Week 1: organisation selection, research and proposal. Week 2: sitemap, content planning and visual design. Week 3: HTML page development and navigation. Week 4: CSS styling, responsive layout and form validation. Week 5: browser testing, proofreading, README completion and GitHub preparation.

### 8. Budget
Estimated academic prototype budget: R0 for software because Visual Studio Code and browser-based development tools are free. A real business implementation would require additional costs for domain registration, hosting, professional imagery, email, maintenance and any server-side form processing.

---

## Proposal 2 — GreenBasket Community Grocery

GreenBasket Community Grocery is a hypothetical independent neighbourhood grocery store serving local households with everyday food, household essentials and selected locally produced goods. The website would provide a simple online catalogue and a clear way for customers to contact the store about product availability, operating hours and collection options. The primary audience would be nearby residents, families and customers who want to check what the store offers before visiting.

The primary website goal would be to increase awareness of the store and encourage visits and enquiries. Objectives would include presenting the product categories clearly, publishing opening hours and contact details, promoting weekly specials, and providing a simple enquiry route. Useful KPIs could include visits to product pages, clicks on the contact page, enquiry submissions and engagement with promotional content.

The proposed five-page structure would contain Home, About, Products, Enquiry and Contact. The Home page would introduce GreenBasket and highlight current specials. The About page would describe the store and its community focus. Products would organise goods into easy-to-scan categories such as fresh produce, pantry items and household essentials. The Enquiry page would allow customers to ask about availability or special orders. Contact would provide the address, hours, telephone number and email.

The design would use fresh, welcoming colours, clear product cards and a mobile-first layout. Navigation would remain visible and predictable, with calls to action such as “View products” and “Ask about a product”. HTML5, CSS3 and JavaScript would be used in Visual Studio Code. Forms would include labels and validation, while the site would avoid unnecessary data collection.

A five-week timeline would cover research and proposal, sitemap and content, HTML development, CSS/JavaScript refinement, and final testing/documentation. The academic prototype would have a R0 software budget, while a real deployment would require hosting, domain, maintenance and possible e-commerce services.

## Selected proposal
**Proposal 1 — BrightHome Electrical & Maintenance** is selected for implementation because its service-based content supports a clear five-page information architecture, strong calls to action and a useful enquiry form while remaining achievable with HTML, CSS and JavaScript in Visual Studio Code.
