# Part 2 Changelog

## Part 1 → Part 2 updates

### CSS and visual design
- Reworked the shared external stylesheet in `css/style.css` so all five pages continue using one consistent stylesheet.
- Added a small CSS reset and `box-sizing` rules for more predictable browser rendering.
- Standardised the BrightHome colour variables, spacing, borders, shadows and rounded components.
- Added a clearer typography scale using `clamp()`, `rem`, `em`-style spacing concepts and responsive sizing.
- Added reusable button, card, panel, banner, form and footer styles to reduce repeated selectors.
- Added `:hover`, `:focus-visible` and `:active` states to improve keyboard and pointer interaction.
- Added CSS Grid and Flexbox layouts for the hero, cards, services, forms, contact content and footer.

### Responsive design
- Added tablet and mobile breakpoints at 64rem, 53.75rem and 37.5rem.
- Desktop multi-column sections collapse progressively to two-column and then single-column layouts.
- Navigation changes to a mobile menu at smaller widths.
- Form fields and the footer switch to a single-column layout on mobile.
- Relative units (`rem`, `%`, `vw`) and `clamp()` are used for scalable spacing and typography.

### Responsive images
- Added `assets/hero-small.svg` as a smaller responsive source.
- Updated the Home page hero image to use `srcset`, `sizes` and a `<picture>` element so the browser can select an appropriate source.

### JavaScript interaction
- Improved the mobile navigation so its accessible label changes between “Open navigation” and “Close navigation”.
- Mobile navigation closes after a page link is selected.
- Service links can pre-select the corresponding service in the enquiry form through the query string.
- Existing client-side form validation and demonstration status messages were retained.

### Documentation and testing
- Added this changelog to document Part 2 changes.
- Added `docs/part2-requirements.md` mapping the assignment requirements to the implementation.
- Added `docs/responsive-testing.md` with desktop, tablet and mobile testing evidence.
- Added screenshot evidence under `docs/screenshots/`.
- Updated the README with Part 2 setup, testing, responsive-design notes and GitHub workflow guidance.

## Part 1 feedback note
No separate Part 1 lecturer feedback/marks document was included with the Part 2 brief supplied for this build. Therefore, no specific lecturer comments have been invented. The project has nevertheless been refined against the Part 2 requirements and the existing Part 1 implementation.

## Colour scheme enhancement
The Part 2 styling uses a consistent BrightHome colour palette: deep navy for headings/navigation, blue for primary accents and links, warm orange for calls-to-action and highlights, with light blue/cream section backgrounds. Hover, focus and status states also use the same palette for consistency and accessibility.
