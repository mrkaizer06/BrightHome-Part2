# Part 2 Responsive Testing Evidence

## Test approach
The site was opened from the project folder in a Chromium browser and checked at representative desktop, tablet and mobile viewport sizes. The same Home page was used so the changes in navigation, grid layout, typography and image sizing can be compared consistently.

## Viewports tested

| Device category | Viewport | Expected behaviour | Result |
|---|---:|---|---|
| Desktop | 1440 × 900 | Full navigation, two-column hero, four statistics columns and desktop spacing | Pass |
| Tablet | 1024 × 900 | Responsive spacing and reduced grid columns; content remains readable | Pass |
| Mobile | 390 × 844 | Compact header with menu button, single-column content, readable buttons and form controls | Pass |

## Evidence
- `screenshots/desktop-1440.png`
- `screenshots/tablet-1024.png`
- `screenshots/mobile-390.png`

## Iteration notes
1. The desktop layout keeps the main content within a readable maximum width.
2. The tablet breakpoint reduces the number of columns before the mobile breakpoint is reached.
3. The mobile navigation is collapsed into a menu button and can be opened with JavaScript.
4. Cards, service panels and forms become single-column where necessary.
5. The hero image remains fluid and uses responsive image sources.
6. Keyboard focus is visually indicated using `:focus-visible`.

## Automated interaction checks
The final build was also checked in Chromium using the same responsive viewport approach:
- Mobile navigation starts collapsed.
- Mobile navigation opens when the menu button is clicked.
- The navigation button label changes to `Close navigation` while open.
- The navigation closes again when toggled.
- Desktop navigation remains visible.
- The Home hero contains `srcset` and `sizes` responsive-image attributes.
- The styled heading is rendered with the project's CSS.

All listed checks passed.

## Browser/device note
These screenshots are automated Chromium viewport evidence. Physical-device rendering can still vary slightly because of operating-system font rendering, browser version and device pixel ratio.
