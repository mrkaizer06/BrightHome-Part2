# Part 2 Requirements Traceability

| Requirement | Implementation/evidence |
|---|---|
| External stylesheet linked to all pages | All five HTML pages link to `css/style.css`. |
| Consistent stylesheet naming | Shared stylesheet is named `style.css`. |
| Base style/reset | CSS reset, root variables, body defaults and form control defaults are defined in `style.css`. |
| Typography styling | `font-family`, `font-size`, `font-weight`, `line-height`, `letter-spacing` and a responsive heading scale are used. |
| CSS Grid/Flexbox | Grid is used for hero, cards, services, forms, contact and footer; Flexbox is used for navigation, buttons and banners. |
| Desktop layout | Multi-column layouts are defined before the responsive breakpoints. |
| Visual styling | Colour, backgrounds, borders, shadows, spacing and rounded corners are defined through reusable CSS. |
| Interactive pseudo-classes | `:hover`, `:focus`, `:focus-visible` and `:active` are implemented. |
| Breakpoints | 64rem, 53.75rem and 37.5rem media queries adjust layout, navigation, spacing and typography. |
| Relative units | `rem`, `%`, `vw`, `clamp()` and fractional grid units are used. |
| Multi-column to single-column | Main content grids progressively collapse to one column on smaller screens. |
| Responsive images | Home hero uses `<picture>`, `srcset` and `sizes`; `hero-small.svg` is included. |
| Browser developer-tool testing | Screenshot evidence is included for desktop, tablet and mobile viewport sizes. |
| Prioritise content / keep simple | Content remains the same core structure while layout and spacing adapt across viewports. |
| README update | README includes Part 2 details, testing evidence and GitHub workflow. |
| Changelog | `docs/changelog.md` records Part 2 changes and the Part 1 feedback limitation. |
| References | Existing Part 1 research references remain in `docs/content-research.md`; Part 2 CSS/HTML references are added to the README. |
