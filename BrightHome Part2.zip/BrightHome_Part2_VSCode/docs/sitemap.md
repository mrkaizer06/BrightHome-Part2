# Sitemap and Website Structure

```text
BrightHome Electrical & Maintenance
│
├── Home (index.html)
│   ├── Hero / introduction
│   ├── Service highlights
│   ├── Website value proposition
│   └── Enquiry call-to-action
│
├── About (about.html)
│   ├── Organisation overview
│   ├── Mission and vision
│   ├── Target audience
│   ├── Website objectives / KPIs
│   └── Current website analysis
│
├── Services (services.html)
│   ├── Electrical repairs
│   ├── Lighting upgrades
│   ├── Home maintenance
│   └── Safety checks
│
├── Enquiry (enquiry.html)
│   ├── Service selector
│   ├── Customer details
│   ├── Job description
│   └── Client-side validation
│
└── Contact (contact.html)
    ├── Phone / email / service area
    ├── Message form
    └── FAQs
```

## Navigation
Every page links to every main page through the shared navigation. Service cards also link directly to the enquiry page with a pre-selected service in the URL. The site uses semantic HTML landmarks (`header`, `nav`, `main`, `section`, `footer`) and a skip link.
