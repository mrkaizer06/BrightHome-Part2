# Part 2 Submission Checklist

## Part 1 continuity and changes
- [x] BrightHome Part 1 website retained and continued.
- [x] Part 1 pages and content retained.
- [x] Part 2 changelog added.
- [x] Part 1 feedback limitation documented rather than inventing lecturer comments.

## CSS desktop solution
- [x] External `style.css` used by all HTML pages.
- [x] Consistent stylesheet naming convention.
- [x] CSS reset/base styles.
- [x] Colour scheme, font family, font sizing, spacing and margins.
- [x] Typography properties and responsive scale.
- [x] CSS Grid/Flexbox layout.
- [x] Desktop multi-column structure.
- [x] Visual styling with colour, backgrounds, borders and shadows.
- [x] `:hover`, `:focus-visible` and `:active` states.

## Responsive design
- [x] Desktop, tablet and mobile breakpoints.
- [x] Media queries.
- [x] Multi-column layouts collapse to single-column layouts.
- [x] Navigation adapts to smaller screens.
- [x] Relative units such as `rem`, `%` and `vw`.
- [x] Responsive typography with `clamp()`.
- [x] Responsive image using `picture`, `srcset` and `sizes`.
- [x] Responsive image source included in assets.

## Testing and documentation
- [x] Desktop screenshot evidence.
- [x] Tablet screenshot evidence.
- [x] Mobile screenshot evidence.
- [x] Responsive testing report.
- [x] Part 2 requirements traceability.
- [x] README updated.
- [x] References retained and Part 2 references added.
- [x] GitHub commit/push instructions included.

## Final student action
- [ ] Connect the project to the student's own GitHub repository.
- [ ] Commit the final files with descriptive commit messages.
- [ ] Push to the remote GitHub repository.
- [ ] Submit the GitHub repository link through the LMS.
