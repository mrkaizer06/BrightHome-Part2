# Content Research and Sourcing

## 1. Research purpose
The website content was planned around the assignment requirements: clear organisational information, relevant page content, legally safe assets, a useful file structure, and a functional HTML navigation system.

## 2. Website and HTML research
- MDN Web Docs explains that forms and buttons are primary tools for user interaction and recommends semantic controls such as real `<button>` elements and properly labelled form controls. This informed the Enquiry and Contact pages.
- MDN explains HTML constraint validation and the use of semantic input types and validation attributes. The project uses `required`, `minlength`, `type="email"` and other native validation features, with JavaScript providing a demonstration response.
- W3C WAI guidance recommends standard HTML form controls and links for keyboard operation and assistive-technology interoperability. The site therefore uses normal links, buttons and labels rather than custom clickable `<div>` elements.

## 3. Organisation content
BrightHome Electrical & Maintenance is fictional. All organisation names, contact details, service descriptions, mission statements and performance targets in the website are original project content and are not presented as claims about a real company.

## 4. Asset sourcing
The website does not rely on copyrighted stock photography. The logo and hero illustration are original SVG assets created specifically for this project. This avoids the need to redistribute third-party photographs and keeps the ZIP self-contained.

## 5. Content decisions
The service descriptions are deliberately general because this is an academic website rather than a real electrical contractor's operational website. The pages include a notice explaining that the organisation is fictional and that real electrical installations should be handled by appropriately qualified professionals.

## 6. References
1. MDN Web Docs. “Forms and buttons in HTML.” https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/HTML_forms
2. MDN Web Docs. “Using HTML form validation and the Constraint Validation API.” https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Constraint_validation
3. W3C Web Accessibility Initiative. “Technique H91: Using HTML form controls and links.” https://www.w3.org/WAI/WCAG21/Techniques/html/H91
4. W3C Web Accessibility Initiative. “Forms Tutorial.” https://www.w3.org/WAI/tutorials/forms/

## 7. Legal/ethical sourcing note
All included visual assets were created in-house as SVG files for this assignment. No third-party image is bundled in the project.
